var C03PacketPlayer = Java.type('net.minecraft.network.play.client.C03PacketPlayer');
var script = registerScript({
    name: 'ChickencraftAirWalk',
    version: '1.0.0',
    authors: ['Temple']
});
script.registerModule({
    name: 'ChickencraftAirWalk',
    category: 'Movement',
    description: 'Airwalk on Chickencraft'

}, function(module) {
    module.on('packet', function(e) {
        var packet = e.getPacket();
        if (packet instanceof C03PacketPlayer) {
            if (mc.thePlayer.motionY < 0)
                packet.onGround = 1;
        }
    });
    module.on('update', function() {
        if (mc.thePlayer.motionY < 0) {
            mc.thePlayer.motionY = 0;
            mc.thePlayer.onGround = 1;
        }
    });
});