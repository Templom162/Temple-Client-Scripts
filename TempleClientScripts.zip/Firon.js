var scriptName = "Firon";
var scriptVersion = 1.0;
var scriptAuthor = "Temple";

var Swords = Java.type('net.minecraft.item.ItemSword');
var BlockPos = Java.type('net.minecraft.util.BlockPos');
var C07PacketPlayerDigging = Java.type('net.minecraft.network.play.client.C07PacketPlayerDigging');
var EnumFacing = Java.type('net.minecraft.util.EnumFacing');
var util = Java.type("net.minecraft.util.MovementInput");
var MathHelper = Java.type("net.minecraft.util.MathHelper");
 // Radians -> Degrees
 Math.rad = function(deg) {
    return deg * Math.PI / 180;
  };

function Strafe() {
    this.getName = function () {
        return "Firon";
    };

    this.getDescription = function () {
        return "Removes fire damages. (Fake)";
    };

    this.getCategory = function () {
        return "Temples";
    };
    this.onMotion = function () {
				var moveSpeed = MathHelper.sqrt_double(mc.thePlayer.motionX * mc.thePlayer.motionX + mc.thePlayer.motionZ * mc.thePlayer.motionZ);
			        var forward = mc.thePlayer.movementInput.moveForward;
                    var strafe = mc.thePlayer.movementInput.moveStrafe;
                    var yaw = mc.thePlayer.rotationYaw;
                    if (forward == 0 && strafe == 0) {
                        mc.thePlayer.motionX = 0;
                        mc.thePlayer.motionZ = 0;
                    } else if (forward != 0) {
                        if (strafe >= 1.0) {
                            yaw = mc.thePlayer.rotationYaw + ((forward > 0.0) ? -45 : 45);
                            strafe = 0;
                        } else if (strafe <= -1.0) {
                            yaw = mc.thePlayer.rotationYaw + ((forward > 0.0) ? 45 : -45);
                            strafe = 0;
                        }
                    }

                    if (forward > 0) {
                        forward = 1;
                    } else if (forward < 0) {
                        forward = -1;
                    }

                    var mx = Math.cos(Math.rad(yaw + 90));
                    var mz = Math.sin(Math.rad(yaw + 90));

                    mc.thePlayer.motionX = forward * moveSpeed * mx + strafe * moveSpeed * mz;
                    mc.thePlayer.motionZ = forward * moveSpeed * mz - strafe * moveSpeed * mx;
    }
    this.onDisable = function() {
    }
    this.onEnable = function() {
    }

    this.addValues = function(values) {
    }
}

var Strafe = new Strafe();
var StrafeClient;

function onEnable() {
	Strafe = moduleManager.registerModule(Strafe);
};

function onDisable() {
	moduleManager.unregisterModule(Strafe);
};