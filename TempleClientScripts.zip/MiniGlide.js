var C03PacketPlayer = Java.type('net.minecraft.network.play.client.C03PacketPlayer');
var script = registerScript({
    name: 'MiniGlide',
    version: '1.0.0',
    authors: ['Temple']
});
script.registerModule({
    name: 'MiniGlideFly',
    category: 'Movement',
    description: 'Mini Glide Fly | Is this a fly?'

}, function(module) {
    module.on('packet', function(e) {
        var packet = e.getPacket();
        if (packet instanceof C03PacketPlayer) {
            if (mc.thePlayer.motionY < -1)
                packet.onGround = 1;
        }
    });
    module.on('update', function() {
        if (mc.thePlayer.motionY < 0) {
            mc.thePlayer.motionY = 0;
            mc.thePlayer.onGround = 1;
        }
    });
});