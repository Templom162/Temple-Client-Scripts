var scriptName="CriticalsV2";var scriptVersion=1.0;var scriptAuthor="Temple";var C03=Java.type("net.minecraft.network.play.client.C03PacketPlayer")
var C04=Java.type("net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition")
var MSTimer=Java.type('net.ccbluex.liquidbounce.utils.timer.MSTimer');var timer=new MSTimer()
var timer2=new MSTimer()
var timer3=new MSTimer()
var timer4=new MSTimer()
function CriticalsV2(){var mode=value.createList("Mode",["CustomPacket","CustomMotion","NoGround","Matrix-TPHop","NCP","Horizon","Spartan","Visual"],"Visual")
var delay=value.createFloat("CustomDelay",0,0,1000)
var hurttime=value.createInteger("CustomHurtTime",10,0,10)
var packety=value.createFloat("PacketY",0.5,0,1)
var motiony=value.createFloat("MotionY",0.42,0,0.42)
var particles=value.createBoolean("SpawnParticlesOnAttack",true)
this.getName=function(){return "CriticalsV2";}
this.getDescription=function(){return "Critical hit only";}
this.getCategory=function(){return "Combat";}
this.getTag=function(){return mode.get()}
this.onEnable=function(){if(mode.get()=="NoGround"){mc.thePlayer.jump()}}
this.onAttack=function(event){var target=event.getTargetEntity()
if(mc.thePlayer.onGround){switch(mode.get()){case "CustomPacket":if(timer.hasTimePassed(delay.get())&&target.hurtTime<=hurttime.get()){mc.thePlayer.sendQueue.addToSendQueue(new C04(mc.thePlayer.posX,mc.thePlayer.posY+packety.get(),mc.thePlayer.posZ,true))
mc.thePlayer.sendQueue.addToSendQueue(new C04(mc.thePlayer.posX,mc.thePlayer.posY,mc.thePlayer.posZ,false))
timer.reset()}
break;case "CustomMotion":if(timer2.hasTimePassed(delay.get())&&target.hurtTime<=hurttime.get()){mc.thePlayer.motionY=motiony.get()
timer2.reset()}
break;case "Matrix-TPHop":if(mc.thePlayer.motionX==0&&mc.thePlayer.motionZ==0){mc.thePlayer.motionY=0.269}
case "NCP":if(timer3.hasTimePassed(500)&&target.hurtTime<=8){mc.thePlayer.sendQueue.addToSendQueue(new C04(mc.thePlayer.posX,mc.thePlayer.posY+0.11,mc.thePlayer.posZ,true))
mc.thePlayer.sendQueue.addToSendQueue(new C04(mc.thePlayer.posX,mc.thePlayer.posY,mc.thePlayer.posZ,false))
timer3.reset()}
break;case "Horizon":if(mc.thePlayer.motionX==0.0&&mc.thePlayer.motionZ==0.0){mc.thePlayer.sendQueue.addToSendQueue(new C04(mc.thePlayer.posX,mc.thePlayer.posY+0.0001,mc.thePlayer.posZ,true))
mc.thePlayer.sendQueue.addToSendQueue(new C04(mc.thePlayer.posX,mc.thePlayer.posY,mc.thePlayer.posZ,false))}
break;case "Spartan":if(timer4.hasTimePassed(600)){mc.thePlayer.sendQueue.addToSendQueue(new C04(mc.thePlayer.posX,mc.thePlayer.posY+0.2,mc.thePlayer.posZ,true))
mc.thePlayer.sendQueue.addToSendQueue(new C04(mc.thePlayer.posX,mc.thePlayer.posY,mc.thePlayer.posZ,false))}
case "Visual":break;case "NoGround":break;}}
if(particles.get()||mode.get()=="Visual"){mc.thePlayer.onCriticalHit(target)}}
this.onPacket=function(event){var packet=event.getPacket()
if(packet instanceof C03&&mode.get()=="NoGround"){packet.onGround=false}}
this.addValues=function(values){values.add(mode)
values.add(delay)
values.add(hurttime)
values.add(packety)
values.add(motiony)
values.add(particles)}}
var CriticalsV2=new CriticalsV2();function onLoad(){}
function onEnable(){moduleManager.registerModule(CriticalsV2);};function onDisable(){moduleManager.unregisterModule(CriticalsV2);};