var script = registerScript({
    name: "ChickenCraftGlide",
    version: "1.0",
    authors: ["sigma jello"]
});

script.registerModule({
        name: "ChickencraftGlide",
        category: "Movement",
        description: "Chickencraft Glide"
    },

    function(module) {
        module.on("enable", function() {
            mc.timer.timerSpeed = 0.7
        });
        module.on('update', function() {
            mc.thePlayer.motionY = -0.2544120001543799
        });
        module.on('disable', function() {
            mc.timer.timerSpeed = 1
        });
    });