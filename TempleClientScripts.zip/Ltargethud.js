var script = registerScript({
    name: "LTargetHUD",
    version: "1.0",
    authors: ["Liulihaocai"]
});
var EntityUtils=Java.type("net.ccbluex.liquidbounce.utils.EntityUtils")
var player = Java.type("net.minecraft.entity.player.EntityPlayer");
var Color = Java.type("java.awt.Color");
var GlStateManager = Java.type("net.minecraft.client.renderer.GlStateManager")
var RenderHelper = Java.type("net.minecraft.client.renderer.RenderHelper")
var OpenGlHelper = Java.type("net.minecraft.client.renderer.OpenGlHelper")
var Fonts = Java.type("net.ccbluex.liquidbounce.ui.font.Fonts");
var GL11 = Java.type("org.lwjgl.opengl.GL11");
var ScaledResolution = Java.type("net.minecraft.client.gui.ScaledResolution");
var Integer = Java.type("java.lang.Integer")
var Red = new Color(255, 40, 80).getRGB();
var White = new Color(255, 255, 255).getRGB();
var Gray = new Color(50,40,70).getRGB();

var fonts=Fonts.getFonts();

script.registerModule({
    name: "LTargetHUD",
    category: "Render",
    description: "A Fancy TargetHUD",
    settings:{
		di: Setting.integer({
            name: "ShowDistance",
            default: 7,
            min: 0,
            max: 15
        }),
        anime: Setting.integer({
            name: "AnimationSpeed",
            default: 20,
            min: 5,
            max: 40
        }),
        tags: Setting.integer({
            name: "MaxTags",
            default: 3,
            min: 1,
            max: 7
        }),
        fontIndex: Setting.integer({
            name: "Font",
            default: 0,
            min: 0,
            max: fonts.length-1
        }),
    }
}, function(module) {
    var targets=[],mcHeight,mcWidth,lastHealth=[],nowHealth=[],dist=[],HPAdd=[],font=Fonts.minecraftFont;
    module.on("enable", function() {
        targets=[];
        lastHealth=[];
        nowHealth=[];
    });
    module.on("update", function() {
        font=fonts[module.settings.fontIndex.get()];
        targets=[];
        for (var i in mc.theWorld.loadedEntityList){
            var entity = mc.theWorld.loadedEntityList[i];
            if(entity.getDistanceToEntity(mc.thePlayer)<module.settings.di.get()&&EntityUtils.isSelected(entity,true)){
                targets.push(entity);
                if(lastHealth[entity.getEntityId()]==undefined||lastHealth[entity.getEntityId()]==null){
                    lastHealth[entity.getEntityId()]=entity.getHealth();
                    nowHealth[entity.getEntityId()]=entity.getHealth();
                    dist[entity.getEntityId()]=0;
                    HPAdd[entity.getEntityId()]=module.settings.anime.get();
                }
                if(nowHealth[entity.getEntityId()]!=entity.getHealth()){
                    lastHealth[entity.getEntityId()]=nowHealth[entity.getEntityId()];
                    nowHealth[entity.getEntityId()]=entity.getHealth();
                    dist[entity.getEntityId()]=(lastHealth[entity.getEntityId()]-nowHealth[entity.getEntityId()])/module.settings.anime.get();
                    HPAdd[entity.getEntityId()]=0;
                }
                if(HPAdd[entity.getEntityId()]<module.settings.anime.get()){
                    lastHealth[entity.getEntityId()]-=dist[entity.getEntityId()];
                    HPAdd[entity.getEntityId()]++;
                }
            }
        }
        targets.sort(function(a,b){
            return (a.getHealth()>b.getHealth())?1:-1;
        })
        targets=targets.slice(0,module.settings.tags.get());
        mcHeight = getScaledHeight();
        mcWidth = getScaledWidth();
    });
    module.on("render2D", function() {
        if(targets.length==0){
            return;
        }
        var offSetWidth = mcWidth / 2 + 46;
        var offSetHeight = mcHeight / 2 + 40;
        for(var i=0;i<targets.length;i++){
            var target=targets[i];
            drawRect(offSetWidth, offSetHeight, offSetWidth+140, offSetHeight+40, Gray);
            font.drawString(target.getName(), offSetWidth + 33, offSetHeight + 5, White);
            drawEntityOnScreen(offSetWidth + 20, offSetHeight + 35, 15, target);
            var colorHP=(target.getHealth()/target.getMaxHealth())*255;
            var woundHP=new Color(new Integer(argCheck(255 - colorHP,0,255)*0.6), new Integer(argCheck(colorHP,0,255)*0.6),0).getRGB();
            colorHP=new Color(new Integer(argCheck(255 - colorHP,0,255)), new Integer(argCheck(colorHP,0,255)),0).getRGB();
            var xend=offSetWidth+33+toPercent(target.getHealth(),target.getMaxHealth());
            drawRect(xend, offSetHeight + 18, offSetWidth+33+toPercent(lastHealth[target.getEntityId()],target.getMaxHealth()), offSetHeight+25,woundHP);
            drawRect(offSetWidth + 33, offSetHeight + 18, xend, offSetHeight+25,colorHP);
            font.drawString("❤", offSetWidth + 33, offSetHeight + 30, Red);
            font.drawString(target.getHealth().toFixed(1)+"", offSetWidth + 43, offSetHeight + 30, White);
            offSetHeight+=50;
        }
    });
});

function drawEntityOnScreen(posX, posY, scale, ent) {
    GlStateManager.enableColorMaterial();
    GlStateManager.pushMatrix();
    GlStateManager.translate(posX, posY, 50.0);
    GlStateManager.scale((-scale), scale, scale);
    GlStateManager.rotate(180.0, 0.0, 0.0, 1.0);
    GlStateManager.rotate(135.0, 0.0, 1.0, 0.0);
    RenderHelper.enableStandardItemLighting();
    GlStateManager.rotate(-135.0, 0.0, 1.0, 0.0);
    GlStateManager.translate(0.0, 0.0, 0.0);
    var rendermanager = mc.getRenderManager();
    rendermanager.setPlayerViewY(180.0);
    rendermanager.setRenderShadow(false);
    rendermanager.renderEntityWithPosYaw(ent, 0.0, 0.0, 0.0, 0.0, 1.0);
    rendermanager.setRenderShadow(true);
    GlStateManager.popMatrix();
    RenderHelper.disableStandardItemLighting();
    GlStateManager.disableRescaleNormal();
    GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
    GlStateManager.disableTexture2D();
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
}

function toPercent(num, total) {
    return (Math.round(num / total * 10000) / 100);
}

function getScaledWidth() {
    var scaledWidth = new ScaledResolution(mc).getScaledWidth();
    return scaledWidth;
}

function getScaledHeight() {
    var scaledHeight = new ScaledResolution(mc).getScaledHeight();
    return scaledHeight;
}

function drawRect(paramXStart, paramYStart, paramXEnd, paramYEnd, color) {
    var alpha = (color >> 24 & 0xFF) / 255;
    var red = (color >> 16 & 0xFF) / 255;
    var green = (color >> 8 & 0xFF) / 255;
    var blue = (color & 0xFF) / 255;
    GL11.glEnable(GL11.GL_BLEND);
    GL11.glDisable(GL11.GL_TEXTURE_2D);
    GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
    GL11.glEnable(GL11.GL_LINE_SMOOTH);
    GL11.glPushMatrix();
    GL11.glColor4f(red, green, blue, alpha);
    GL11.glBegin(GL11.GL_TRIANGLE_FAN);
    GL11.glVertex2d(paramXEnd, paramYStart);
    GL11.glVertex2d(paramXStart, paramYStart);
    GL11.glVertex2d(paramXStart, paramYEnd);
    GL11.glVertex2d(paramXEnd, paramYEnd);
    GL11.glEnd();
    GL11.glPopMatrix();
    GL11.glEnable(GL11.GL_TEXTURE_2D);
    GL11.glDisable(GL11.GL_BLEND);
    GL11.glDisable(GL11.GL_LINE_SMOOTH);
    GL11.glColor4f(1, 1, 1, 1);
}
function argCheck(num,min,max){
    if(num>max){
        return max;
    }
    if(num<min){
        return min;
    }
    return num;
}