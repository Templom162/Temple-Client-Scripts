var script = registerScript({
    name: "ChickenCraftGlide9999IQ",
    version: "1.0",
    authors: ["Templom"]
});

script.registerModule({
        name: "FastFall",
        category: "Movement",
        description: "Super falling into the void and LowHop speed"
    },

    function(module) {
        module.on("enable", function() {
            mc.timer.timerSpeed = 0.7
        });
        module.on('update', function() {
            mc.thePlayer.motionY = -9.9999999999999999
        });
        module.on('disable', function() {
            mc.timer.timerSpeed = 1
        });
    });