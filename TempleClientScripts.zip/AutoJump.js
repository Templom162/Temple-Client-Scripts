/// api_version=2
var script = registerScript({
    name: "AutoJump",
    version: "0.1",
    authors: ["Temple"]
});

var BlockPos = Java.type('net.minecraft.util.BlockPos');
var Block = Java.type('net.minecraft.block.Block');
var Blocks = Java.type('net.minecraft.init.Blocks');

var blocks = [];
var jump = 0;

script.registerModule({
    name: "AutoJump",
    description: "Jump automaticly!",
    category: "Movement",
    settings: {
    }  
}, function (module) {
    module.on("update", function () {
        if (mc.theWorld.isAirBlock(new BlockPos(mc.thePlayer.posX,mc.thePlayer.posY-1,mc.thePlayer.posZ)) || mc.thePlayer.inWater) {
            if (mc.thePlayer.fallDistance >= 1) {
                mc.theWorld.setBlockState(new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY-1, mc.thePlayer.posZ), Blocks.air.getDefaultState());
                blocks.push(new BlockPos(mc.thePlayer.posX,mc.thePlayer.posY-1,mc.thePlayer.posZ));
            }
        }
        if (mc.thePlayer.onGround) {
            mc.thePlayer.jump();
        }
    });
    module.on("enable", function () {
        jump = 0;
        blocks = [];
    });
    module.on("disable", function () {
        for (i = 0;i < blocks.length;i++) {
            mc.theWorld.destroyBlock(blocks[i], false);
        }
    });
});