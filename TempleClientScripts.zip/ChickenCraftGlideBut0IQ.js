var script = registerScript({
    name: "NCPFly",
    version: "1.0",
    authors: ["sigma jello"]
});

script.registerModule({
        name: "TempleCraftSlowFly",
        category: "Movement",
        description: "Fly on TempleCraft. (But slow.)"
    },

    function(module) {
        module.on("enable", function() {
            mc.timer.timerSpeed = 0.7
        });
        module.on('update', function() {
            mc.thePlayer.motionY = -0.0000000000000000
        });
        module.on('disable', function() {
            mc.timer.timerSpeed = 1
        });
    });