/// api_version=2
var LB = Java.type("net.ccbluex.liquidbounce.LiquidBounce");
var script = registerScript({
    name: "Matrix_BilalWare_bugup",
	version: "6.9.0",
	authors: ["Daniel"]
	});
	
	script.registerModule({
	name: "Fly mode: BugUp",
	category: "Movement",
	description: "Fly mode: BugUp"
	}, function (module) {
		module.on("enable", function() {
			LB.commandManager.executeCommands(".bind blink f");
			LB.commandManager.executeCommands(".fly mode clip");
                        LB.commandManager.executeCommands(".fly clip-y 10");
                        LB.commandManager.executeCommands(".fly clip-z 0");
                        LB.commandManager.executeCommands(".fly clip-x 0");
			LB.commandManager.executeCommands(".fly mode clip");
                        LB.commandManager.executeCommands(".blink pulsedelay 736");
                        LB.commandManager.executeCommands(".fly clip-motiony 0");
                        LB.commandManager.executeCommands(".fly clip-delay 909");
                        LB.commandManager.executeCommands(".fly clip-timer 1");
		});
	});
	