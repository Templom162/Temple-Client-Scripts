var scriptName = "Inv+";
var scriptVersion = 1.0.0;
var scriptAuthor = "Temple";
var C03PacketPlayer = Java.type('net.minecraft.network.play.client.C03PacketPlayer');
var noFallModule = moduleManager.getModule("NoFall");
var Keyboard = Java.type("org.lwjgl.input.Keyboard");

var cleanStep = new CleanStep();

var client;

function CleanStep() {
    var Mode = value.createList("Mode", ["Normal", "ZeroDay", "TempleClient"], "TempleClient");
    this.getName = function() {
        return "Inv+";
    };

    this.getDescription = function() {
        return "Allows you to change the inventory type. (Fake)";
    };

    this.getCategory = function() {
        return "Temples";
    };
    this.addValues = function(values) {
        values.add(Mode);
    };
    this.getTag = function() {
        return Mode.get();
    }
    this.onEnable = function() {}
    this.onJump = function(event) {
        if (this.airStepping) {
            event.cancelEvent()
        }
    }
    this.onUpdate = function() {
        switch (Mode.get()) {
            case "Basic":
                if ((mc.thePlayer.isCollidedHorizontally) && !mc.thePlayer.onGround && !(mc.thePlayer.isCollidedVertically && mc.thePlayer.motionY <= 0)) {
                    mc.thePlayer.onGround = true;
                    this.airStepping = true;
                } else {
                    this.airStepping = false;
                }
                break;
            case "Edge":
                if (mc.thePlayer.onGround) {
                    wasonground = true;
                }
                if (mc.thePlayer.motionY <= 0 && wasonground == true && (mc.thePlayer.isCollidedHorizontally) && !mc.thePlayer.onGround && !mc.thePlayer.isCollidedVertically) {
                    mc.thePlayer.onGround = true;
                    this.airStepping = true;
                    wasonground = false;
                } else {
                    if (mc.thePlayer.motionY <= 0 && !mc.thePlayer.onGround && wasonground == true) {
                        this.airStepping = false;
                        wasonground = false;
                    }
                }
                break;
            case "NCP":
                if (mc.thePlayer.motionY <= 0 && mc.thePlayer.fallDistance >= 0.078 && (mc.thePlayer.isCollidedHorizontally) && !mc.thePlayer.onGround && !mc.thePlayer.isCollidedVertically) {
                    mc.thePlayer.onGround = true;
                    this.airStepping = true;
                } else {
                    this.airStepping = false;
                }
                break;
        }
    }
    this.onDisable = function() {}
}

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(cleanStep);
}

function onDisable() {
    moduleManager.unregisterModule(client);
}