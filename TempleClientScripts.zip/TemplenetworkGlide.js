/// api_version=2
var script = registerScript({
    name: "TempleGlide",
    version: "0.1",
    authors: ["Temple"]
});

var BlockPos = Java.type('net.minecraft.util.BlockPos');
var Block = Java.type('net.minecraft.block.Block');
var Blocks = Java.type('net.minecraft.init.Blocks');

var blocks = [];

script.registerModule({
    name: "TempleGlide",
    description: "Gilde on TempleCraft. (§cWARNING§r: The glide is can lag the game!))",
    category: "Movement",
    settings: {
    }  
}, function (module) {
    module.on("update", function () {
        if (mc.theWorld.isAirBlock(new BlockPos(mc.thePlayer.posX,mc.thePlayer.posY-1,mc.thePlayer.posZ)) || mc.thePlayer.inWater) {
            if (mc.thePlayer.fallDistance >= 1) {
                mc.theWorld.setBlockState(new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY-1, mc.thePlayer.posZ), Blocks.barrier.getDefaultState());
                blocks.push(new BlockPos(mc.thePlayer.posX,mc.thePlayer.posY-1,mc.thePlayer.posZ));
            }
        }
        if (mc.thePlayer.onGround) {
            mc.thePlayer.onGround();
        }
    });
    module.on("enable", function () {
        blocks = [];
    });
    module.on("disable", function () {
        for (i = 0;i < blocks.length;i++) {
            mc.theWorld.destroyBlock(blocks[i], false);
        }
    });
});