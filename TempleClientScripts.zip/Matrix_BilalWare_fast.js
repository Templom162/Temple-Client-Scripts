/// api_version=2
var LB = Java.type("net.ccbluex.liquidbounce.LiquidBounce");
var script = registerScript({
    name: "WTF1",
	version: "6.9.0",
	authors: ["Daniel"]
	});
	
	script.registerModule({
	name: "Fly mode: Fast Fly",
	category: "Movement",
	description: "Fly mode: Fast Fly"
	}, function (module) {
		module.on("enable", function() {
			LB.commandManager.executeCommands(".bind blink NONE");
			LB.commandManager.executeCommands(".fly mode clip");
                        LB.commandManager.executeCommands(".blink pulsedelay 736");
                        LB.commandManager.executeCommands(".fly clip-motiony -0.03");
                        LB.commandManager.executeCommands(".fly clip-y 0");
                        LB.commandManager.executeCommands(".fly clip-z 6.50");
                        LB.commandManager.executeCommands(".fly clip-x 6.50");
                        LB.commandManager.executeCommands(".fly clip-delay 0");
                        LB.commandManager.executeCommands(".fly clip-timer 0.40");
		});
	});
	