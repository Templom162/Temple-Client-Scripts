/// api_version=2
var LB = Java.type("net.ccbluex.liquidbounce.LiquidBounce");
var script = registerScript({
    name: "MatrixSeks",
	version: "6.9.0",
	authors: ["Daniel"]
	});
	
	script.registerModule({
	name: "MatrixEpicModule",
	category: "Movement",
	description: "it does intercourse with matrix anticheats."
	}, function (module) {
		module.on("enable", function() {
			LB.commandManager.executeCommands(".t fly");
			LB.commandManager.executeCommands(".t blink");
			LB.commandManager.executeCommands(".fly mode clip");
		});
	});
	